MY MUSIC PLAYER

В проект уже встроены 3 аудиофайла:
1. Ransom — Lil Tecca
2. Balada — Gusttavo Lima
3. Runaway — AURORA

Открой index.html. Папку music не удаляй.
