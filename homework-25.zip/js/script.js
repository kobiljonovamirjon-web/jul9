const songs = [
    {
        title: "Ransom",
        artist: "Lil Tecca",
        src: "music/Ransom - Lil Tecca.mp3"
    },

    {
        title: "Balada",
        artist: "Gusttavo Lima",
        src: "music/Balada - Gusttavo Lima.mp3"
    },

    {
        title: "Runaway",
        artist: "AURORA",
        src: "music/Runaway - AURORA.m4a"
    }
];


const audio = document.getElementById("audio");

const trackList = document.getElementById("trackList");

const playBtn = document.getElementById("playBtn");

const prevBtn = document.getElementById("prevBtn");

const nextBtn = document.getElementById("nextBtn");

const progress = document.getElementById("progress");

const volume = document.getElementById("volume");

const currentTimeEl =
    document.getElementById("currentTime");

const durationEl =
    document.getElementById("duration");

const nowTitle =
    document.getElementById("nowTitle");

const nowArtist =
    document.getElementById("nowArtist");

const disc =
    document.getElementById("disc");

const songCount =
    document.getElementById("songCount");

const fileInput =
    document.getElementById("fileInput");

const repeatBtn =
    document.getElementById("repeatBtn");

const randomBtn =
    document.getElementById("randomBtn");


let currentIndex = -1;


/* ================================= */
/* ФОРМАТ ВРЕМЕНИ                    */
/* ================================= */

function formatTime(seconds) {

    if (!Number.isFinite(seconds)) {
        return "0:00";
    }

    const minutes =
        Math.floor(seconds / 60);

    const secondsPart =
        Math.floor(seconds % 60)
            .toString()
            .padStart(2, "0");

    return `${minutes}:${secondsPart}`;
}


/* ================================= */
/* ПОКАЗ ПЕСЕН                       */
/* ================================= */

function renderSongs() {

    songCount.textContent =
        `${songs.length} песни`;

    trackList.innerHTML = "";

    songs.forEach((song, index) => {

        const row =
            document.createElement("div");

        row.className =
            "track" +
            (index === currentIndex
                ? " active"
                : "");


        row.innerHTML = `
            <div class="num">
                ${index + 1}
            </div>

            <div class="cover">
                🎵
            </div>

            <div class="info">
                <strong>
                    ${song.title}
                </strong>

                <span>
                    ${song.artist}
                </span>
            </div>

            <div
                class="time"
                id="time-${index}"
            >
                —
            </div>

            <button
                class="play-track"
                title="Воспроизвести"
            >
                ▶
            </button>
        `;


        const playTrack =
            row.querySelector(".play-track");


        playTrack.addEventListener(
            "click",
            () => playSong(index)
        );


        row.addEventListener(
            "dblclick",
            () => playSong(index)
        );


        trackList.appendChild(row);
    });
}


/* ================================= */
/* ВОСПРОИЗВЕДЕНИЕ                   */
/* ================================= */

function playSong(index) {

    if (!songs[index]) {
        return;
    }


    currentIndex = index;


    const song =
        songs[index];


    audio.src =
        song.src;


    nowTitle.textContent =
        song.title;


    nowArtist.textContent =
        song.artist;


    audio.load();


    audio.play()
        .then(() => {

            playBtn.textContent = "⏸";

            disc.classList.add(
                "playing"
            );

            renderSongs();

        })
        .catch(() => {

            alert(
                "Не удалось воспроизвести музыку. Проверь папку music."
            );

        });
}


/* ================================= */
/* PLAY / PAUSE                      */
/* ================================= */

playBtn.addEventListener(
    "click",
    () => {

        if (currentIndex === -1) {

            playSong(0);

            return;
        }


        if (audio.paused) {

            audio.play();

        } else {

            audio.pause();

        }
    }
);


/* ================================= */
/* ПРЕДЫДУЩАЯ                        */
/* ================================= */

prevBtn.addEventListener(
    "click",
    () => {

        if (!songs.length) {
            return;
        }


        let newIndex =
            currentIndex - 1;


        if (newIndex < 0) {
            newIndex =
                songs.length - 1;
        }


        playSong(newIndex);
    }
);


/* ================================= */
/* СЛЕДУЮЩАЯ                         */
/* ================================= */

nextBtn.addEventListener(
    "click",
    () => {

        if (!songs.length) {
            return;
        }


        let newIndex =
            currentIndex + 1;


        if (newIndex >= songs.length) {
            newIndex = 0;
        }


        playSong(newIndex);
    }
);


/* ================================= */
/* СЛУЧАЙНАЯ ПЕСНЯ                   */
/* ================================= */

function playRandomSong() {

    if (!songs.length) {
        return;
    }


    if (songs.length === 1) {

        playSong(0);

        return;
    }


    let randomIndex;


    do {

        randomIndex =
            Math.floor(
                Math.random() *
                songs.length
            );

    } while (
        randomIndex === currentIndex
    );


    playSong(randomIndex);
}


/* ================================= */
/* КНОПКА "ПОMEНЯТЬ"                 */
/* ================================= */

randomBtn.addEventListener(
    "click",
    () => {

        playRandomSong();

    }
);


/* ================================= */
/* ПОВТОР ТЕКУЩЕЙ ПЕСНИ              */
/* ================================= */

repeatBtn.addEventListener(
    "click",
    () => {

        if (currentIndex === -1) {
            playSong(0);
            return;
        }


        audio.currentTime = 0;


        audio.play();


        repeatBtn.classList.add(
            "active"
        );


        setTimeout(() => {

            repeatBtn.classList.remove(
                "active"
            );

        }, 500);

    }
);


/* ================================= */
/* САМАЯ ВАЖНАЯ ЧАСТЬ                */
/* ================================= */
/*
   Когда музыка закончилась,
   автоматически выбираем случайную
   другую песню.
*/

audio.addEventListener(
    "ended",
    () => {

        playRandomSong();

    }
);


/* ================================= */
/* ПРОГРЕСС                           */
/* ================================= */

audio.addEventListener(
    "timeupdate",
    () => {

        if (!audio.duration) {
            return;
        }


        progress.value =
            (audio.currentTime /
                audio.duration) * 100;


        currentTimeEl.textContent =
            formatTime(
                audio.currentTime
            );
    }
);


/* ================================= */
/* ПЕРЕМЕЩЕНИЕ ПО ПОЛОСЕ              */
/* ================================= */

progress.addEventListener(
    "input",
    () => {

        if (!audio.duration) {
            return;
        }


        audio.currentTime =
            (progress.value / 100) *
            audio.duration;
    }
);


/* ================================= */
/* МЕТАДАННЫЕ                        */
/* ================================= */

audio.addEventListener(
    "loadedmetadata",
    () => {

        durationEl.textContent =
            formatTime(
                audio.duration
            );


        if (currentIndex >= 0) {

            const time =
                document.getElementById(
                    `time-${currentIndex}`
                );


            if (time) {

                time.textContent =
                    formatTime(
                        audio.duration
                    );
            }
        }
    }
);


/* ================================= */
/* ГРОМКОСТЬ                         */
/* ================================= */

volume.addEventListener(
    "input",
    () => {

        audio.volume =
            volume.value / 100;
    }
);


audio.volume = 0.7;


/* ================================= */
/* PLAY                               */
/* ================================= */

audio.addEventListener(
    "play",
    () => {

        playBtn.textContent = "⏸";

        disc.classList.add(
            "playing"
        );
    }
);


/* ================================= */
/* PAUSE                              */
/* ================================= */

audio.addEventListener(
    "pause",
    () => {

        playBtn.textContent = "▶";

        disc.classList.remove(
            "playing"
        );
    }
);


/* ================================= */
/* ДОБАВЛЕНИЕ СВОЕЙ МУЗЫКИ           */
/* ================================= */

fileInput.addEventListener(
    "change",
    () => {

        for (
            const file of fileInput.files
        ) {

            const url =
                URL.createObjectURL(file);


            songs.push({

                title:
                    file.name.replace(
                        /\.[^/.]+$/,
                        ""
                    ),

                artist:
                    "Добавленная музыка",

                src: url
            });
        }


        renderSongs();


        fileInput.value = "";
    }
);


/* ================================= */
/* КЛАВИАТУРА                         */
/* ================================= */

document.addEventListener(
    "keydown",
    (event) => {

        if (
            event.code === "Space" &&
            event.target.tagName !== "INPUT"
        ) {

            event.preventDefault();

            playBtn.click();
        }


        if (event.code === "ArrowRight") {

            playRandomSong();
        }


        if (event.code === "ArrowLeft") {

            prevBtn.click();
        }
    }
);


/* ================================= */
/* ЗАПУСК                            */
/* ================================= */

renderSongs();